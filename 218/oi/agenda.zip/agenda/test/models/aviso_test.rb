require 'test_helper'

class AvisoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
