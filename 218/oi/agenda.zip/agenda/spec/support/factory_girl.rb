RSpec.configure do |config|
    Config.include FactoryGirl::Syntax::Methods
end