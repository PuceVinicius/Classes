FactoryGirl.define do
    factory :atividade do
        nome 'Lig Leg'
        horario_inicio '11:00'
        horario_fim '12:00'
        sala 'b5'
        professor 'Puce'
    end
end
