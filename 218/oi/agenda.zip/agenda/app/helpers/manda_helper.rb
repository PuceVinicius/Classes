module MandaHelper
end
