class MandaController < ApplicationController
  def index
  end
end
