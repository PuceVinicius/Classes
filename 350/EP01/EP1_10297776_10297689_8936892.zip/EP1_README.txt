Integrantes:

Gabriel Miranda de Araújo - 10297689
Vinícius Moreno da Silva - 10297776
Lucas Marques Gasparino - 8936892