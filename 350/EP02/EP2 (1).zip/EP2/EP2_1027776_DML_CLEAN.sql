Delete from "Rel_Dis_Mod";
Delete from "Prereq_Rel_Dis_Mod";
Delete from "Disciplinas_Rel_Cur_Tri";
Delete from "Oferecimento";
Delete from "Disciplina_Oferecimento";
Delete from "Professor";
Delete from "Grade_Curriculo";
Delete from "Disciplina_Oferecimento";
Delete from "Administra";
Delete from "Administrador";
Delete from "Planeja";
Delete from "Aluno";
Delete from "Periodo_Curriculo";
Delete from "Curriculo";

Delete from pf_se;
Delete from "Cursa";
Delete from "User";
Delete from "Servico";
Delete from "Modulo";
Delete from "Disciplina_Info";


Delete from "Perfil";
Delete from "Trilha";


Delete from "Periodo_Disciplina";
Delete from us_pf;

Delete from "Rel_Cur_Tri";
Delete from "Pessoa";