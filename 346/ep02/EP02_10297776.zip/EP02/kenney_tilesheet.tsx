<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="kenney_tileset" tilewidth="111" tileheight="128" tilecount="168" columns="21">
 <image source="tilesheet_complete.png" width="2331" height="1025"/>
</tileset>
