function love.conf(t)
	--t.console = true
	t.window.width = 800                
    t.window.height = 600
end