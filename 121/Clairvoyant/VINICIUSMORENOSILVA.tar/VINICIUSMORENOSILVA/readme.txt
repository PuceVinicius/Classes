Ao utilizar priority queue no problema, devido a sua estrutura, obtem-se
complexidade O(N log m) e como utilizou-se hashmaps para a construção de aux[],
obtem-se tambem complexidade O(N log n). Assim, com uma simples manipulação
dos logaritimos, chega-se em O(N (log n + log m)).