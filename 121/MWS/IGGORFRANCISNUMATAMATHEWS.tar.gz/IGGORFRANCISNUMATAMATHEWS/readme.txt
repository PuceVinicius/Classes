Este ep tem complexidade N log K, pois mesmo com um laço dentro de outro, um 
laço somente percorrera a lista de N elementos quando o outro parar de 
percorre-la, e nunca lendo a lista N mais de duas vezes. Log k e dado pela
busca binaria usada para procurar as palavras de N na lista K.