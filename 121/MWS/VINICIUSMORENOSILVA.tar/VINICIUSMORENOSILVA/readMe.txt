ele rodara linearmente pois os dois loops sao feitos unicamente
para mover os ponteiros ao longo da array de tamanho n. Então, eles
nunca vão precisa passar pelo vetor mais de uma vez do jeito
que o programa foi escrito. Não como os ponteiros darem
overlap pois um é limitante do loop do outro. Já a parte logaritmica
do codigo é garantida pela busca binaria feita nas k palavras